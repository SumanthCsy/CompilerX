import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Proxy for code execution with CodeX as primary and Piston as fallback
  app.post("/api/compile", async (req, res) => {
    const { language, version, files, stdin } = req.body;
    const mainFile = files[0];
    
    // Language mapping for CodeX
    const codexMap: Record<string, string> = {
      'python': 'py',
      'javascript': 'js',
      'cpp': 'cpp',
      'c': 'c',
      'java': 'java',
      'go': 'go',
      'csharp': 'cs',
      'ruby': 'rb',
      'kotlin': 'kt',
      'php': 'php',
      'rust': 'rs',
      'typescript': 'ts'
    };

    const codexLang = codexMap[language];

    // 1. Try CodeX API First (Reliable Alternative)
    if (codexLang) {
      try {
        console.log(`Attempting CodeX execution for ${language}...`);
        const codexResponse = await axios.post("https://api.codex.jaagrav.in", {
          code: mainFile.content,
          language: codexLang,
          input: stdin || ""
        }, { timeout: 12000 });

        const data = codexResponse.data;
        if (data && (data.output || data.error || data.timeStamp)) {
          return res.json({
            language,
            version: "latest",
            run: {
              stdout: data.output || "",
              stderr: data.error || "",
              code: data.error ? 1 : 0,
              signal: null,
              output: data.output || data.error || ""
            }
          });
        }
      } catch (error: any) {
        console.warn("CodeX API failed, falling back to Judge0...", error.message);
      }
    }

    // 2. Fallback to Judge0 (Public CE Instance)
    const judge0Map: Record<string, number> = {
      'python': 71,
      'javascript': 63,
      'cpp': 54,
      'c': 50,
      'java': 62,
      'go': 60,
      'csharp': 51,
      'ruby': 72,
      'rust': 73,
      'php': 68,
      'typescript': 74
    };

    const judge0Id = judge0Map[language];
    if (judge0Id) {
      try {
        console.log(`Attempting Judge0 execution for ${language}...`);
        const judgeResponse = await axios.post("https://ce.judge0.com/submissions?base64_encoded=false&wait=true", {
          source_code: mainFile.content,
          language_id: judge0Id,
          stdin: stdin || ""
        }, { timeout: 15000 });

        const data = judgeResponse.data;
        if (data && (data.stdout || data.stderr || data.compile_output || data.status)) {
          return res.json({
            language,
            version: "latest",
            run: {
              stdout: data.stdout || "",
              stderr: data.stderr || data.compile_output || "",
              code: data.status?.id === 3 ? 0 : 1,
              signal: null,
              output: data.stdout || data.stderr || data.compile_output || data.status?.description || ""
            }
          });
        }
      } catch (error: any) {
        console.warn("Judge0 API failed, falling back to Piston mirrors...", error.message);
      }
    }

    // 3. Fallback to Piston Mirrors (If CodeX and Judge0 fail)
    const PISTON_MIRRORS = [
      process.env.PISTON_API_URL,
      "https://piston.deno.dev/api/v2/piston",
      "https://emkc.org/api/v2/piston"
    ].filter(Boolean) as string[];

    for (const baseUrl of PISTON_MIRRORS) {
      try {
        const EXECUTE_URL = `${baseUrl}/execute`;
        const RUNTIMES_URL = `${baseUrl}/runtimes`;
        let resolvedVersion = version;

        if (!resolvedVersion || resolvedVersion === "*") {
          try {
            const runtimesResponse = await axios.get(RUNTIMES_URL, { timeout: 2000 });
            const runtime = runtimesResponse.data.find((r: any) => r.language === language || r.aliases.includes(language));
            if (runtime) resolvedVersion = runtime.version;
          } catch (e) {}
        }

        const response = await axios.post(EXECUTE_URL, {
          language,
          version: resolvedVersion || "*",
          files,
          stdin,
        }, { timeout: 8000 });

        return res.json(response.data);
      } catch (error: any) {
        console.warn(`Piston mirror ${baseUrl} failed...`);
      }
    }

    // 4. Final Error
    res.status(503).json({
      message: "All code execution services (CodeX, Judge0, Piston) are currently unavailable. Please check your internet or host a private instance.",
      error: "Service Unavailable"
    });
  });

  // Get available Piston runtimes with fallback
  app.get("/api/runtimes", async (req, res) => {
    const PISTON_MIRRORS = [
      process.env.PISTON_API_URL,
      "https://piston.deno.dev/api/v2/piston",
      "https://emkc.org/api/v2/piston"
    ].filter(Boolean) as string[];

    for (const baseUrl of PISTON_MIRRORS) {
      try {
        const response = await axios.get(`${baseUrl}/runtimes`, { timeout: 3000 });
        return res.json(response.data);
      } catch (error: any) {
        console.error(`Runtimes fetch failed for ${baseUrl}`);
        continue;
      }
    }
    res.status(500).json({ error: "Failed to fetch runtimes from all mirrors" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
