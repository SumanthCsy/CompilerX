import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import CodeEditor from './components/Editor';
import Terminal from './components/Terminal';
import AIChat from './components/AIChat';
import { FileNode, ExecutionResult } from './types';
import { DEFAULT_FILES, SUPPORTED_LANGUAGES, LANGUAGE_VERSIONS } from './constants';
import axios from 'axios';

export default function App() {
  const [files, setFiles] = useState<FileNode[]>(() => {
    const saved = localStorage.getItem('compilerx_files');
    return saved ? JSON.parse(saved) : DEFAULT_FILES;
  });
  const [activeFileId, setActiveFileId] = useState<string>(files[0]?.id || '');
  const [output, setOutput] = useState<ExecutionResult | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [stdin, setStdin] = useState('');

  const activeFile = files.find(f => f.id === activeFileId) || null;

  // Persistence
  useEffect(() => {
    localStorage.setItem('compilerx_files', JSON.stringify(files));
  }, [files]);

  const handleCodeChange = (newContent: string | undefined) => {
    if (newContent === undefined) return;
    setFiles(prev => prev.map(f => 
      f.id === activeFileId ? { ...f, content: newContent } : f
    ));
  };

  const handleFileSelect = (id: string) => {
    setActiveFileId(id);
  };

  const handleFileClose = (id: string) => {
    const newFiles = files.filter(f => f.id !== id);
    setFiles(newFiles);
    if (activeFileId === id && newFiles.length > 0) {
      setActiveFileId(newFiles[0].id);
    } else if (newFiles.length === 0) {
      setActiveFileId('');
    }
  };

  const handleFileCreate = () => {
    const id = Math.random().toString(36).substr(2, 9);
    const newFile: FileNode = {
      id,
      name: `untitled_${files.length + 1}.js`,
      content: '// New cyberpunk script\n',
      language: 'javascript',
    };
    setFiles(prev => [...prev, newFile]);
    setActiveFileId(id);
  };

  const handleLanguageChange = (lang: string) => {
    if (!activeFile) return;
    const ext = SUPPORTED_LANGUAGES[lang] || 'txt';
    const newName = activeFile.name.split('.')[0] + '.' + ext;
    setFiles(prev => prev.map(f => 
      f.id === activeFileId ? { ...f, language: lang, name: newName } : f
    ));
  };

  const runCode = async () => {
    if (!activeFile || isExecuting) return;

    setIsExecuting(true);
    setOutput(null);

    try {
      const response = await axios.post('/api/compile', {
        language: activeFile.language,
        version: LANGUAGE_VERSIONS[activeFile.language] || '*',
        stdin: stdin,
        files: [
          {
            name: activeFile.name,
            content: activeFile.content,
          }
        ],
      });
      setOutput(response.data);
    } catch (error: any) {
      console.error("Execution failed:", error);
      let errorMessage = error.response?.data?.message || error.message || 'Execution failed. Check network connection or server status.';
      
      if (error.response?.status === 403) {
        errorMessage = "CRITICAL: All public Piston API mirrors are currently restricted or whitelisted. To continue using CompilerX for backend execution, please host your own Piston instance and update the PISTON_API_URL in the environment settings.";
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = "TIMEOUT: The code execution service is taking too long to respond. Please try again or check your internet connection.";
      }

      setOutput({
        run: {
          stdout: '',
          stderr: errorMessage,
          code: 1,
          signal: null,
          output: errorMessage
        }
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSave = () => {
    // Already handled by useEffect persistence, but could trigger a toast
    console.log("Project saved to local storage");
  };

  const handleDownload = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const applyAICode = (code: string) => {
    handleCodeChange(code);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        runCode();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeFile, isExecuting]);

  return (
    <div className={`flex flex-col h-screen overflow-hidden bg-cyber-bg scanline relative ${window.innerWidth < 768 ? 'mobile-theme' : 'desktop-theme'}`}>
      <Navbar 
        language={activeFile?.language || 'javascript'}
        onLanguageChange={handleLanguageChange}
        onRun={runCode}
        onSave={handleSave}
        onDownload={handleDownload}
        isRunning={isExecuting}
        onToggleAI={() => setIsAIChatOpen(!isAIChatOpen)}
        isAIOpen={isAIChatOpen}
      />
      
      <div className="flex-1 flex overflow-hidden relative">
        <div className={`${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 absolute md:relative z-30 h-full`}>
          <Sidebar 
            files={files}
            activeFileId={activeFileId}
            onFileSelect={(id) => {
              handleFileSelect(id);
              if (window.innerWidth < 768) setIsSidebarOpen(false);
            }}
            onFileClose={handleFileClose}
            onFileCreate={handleFileCreate}
          />
        </div>
        
        <main className="flex-1 flex flex-col min-w-0 border-r border-cyber-border relative">
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 min-h-0">
              <CodeEditor 
                file={activeFile}
                onChange={handleCodeChange}
              />
            </div>
            <Terminal 
              result={output}
              isLoading={isExecuting}
              onClear={() => setOutput(null)}
              stdin={stdin}
              onStdinChange={setStdin}
            />
          </div>
        </main>

        <div className={`${isAIChatOpen ? 'translate-x-0' : 'translate-x-full'} transition-transform duration-300 fixed md:relative right-0 top-0 bottom-0 z-40 w-full md:w-80 h-full bg-cyber-bg/95 md:bg-transparent`}>
          <AIChat 
            activeFile={activeFile}
            onApplyCode={(code) => {
              applyAICode(code);
              if (window.innerWidth < 768) setIsAIChatOpen(false);
            }}
            onClose={() => setIsAIChatOpen(false)}
          />
        </div>
      </div>

      <footer className="h-6 bg-cyber-panel border-t border-cyber-border px-4 flex items-center justify-between text-[10px] text-gray-500 font-mono">
        <div className="flex gap-4">
          <span className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-neon-green" />
            CPU: 12%
          </span>
          <span className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-neon-cyan" />
            MEM: 256MB
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-neon-cyan/50">Developed by @Sumanth Csy</span>
          <span className="text-gray-600">LN {activeFile?.content.split('\n').length || 0}, COL 1</span>
        </div>
      </footer>
    </div>
  );
}
