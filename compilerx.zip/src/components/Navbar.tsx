import React from 'react';
import { Cpu, Play, Save, Download, Terminal, Settings, Globe, MessageSquare, X } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../constants';

interface NavbarProps {
  language: string;
  onLanguageChange: (lang: string) => void;
  onRun: () => void;
  onSave: () => void;
  onDownload: () => void;
  isRunning: boolean;
  onToggleAI: () => void;
  isAIOpen: boolean;
}

export default function Navbar({ 
  language, 
  onLanguageChange, 
  onRun, 
  onSave, 
  onDownload, 
  isRunning,
  onToggleAI,
  isAIOpen
}: NavbarProps) {
  return (
    <nav className="h-14 bg-cyber-panel border-b border-cyber-border flex items-center justify-between px-4 md:px-6 z-20 shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
      <div className="flex items-center gap-4 md:gap-8">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="w-7 h-7 md:w-8 md:h-8 bg-neon-cyan rounded flex items-center justify-center shadow-[0_0_15px_rgba(0,243,255,0.5)]">
            <Cpu size={16} className="text-black" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm md:text-lg font-black tracking-tighter text-white leading-none">COMPILER<span className="text-neon-cyan">X</span></span>
            <span className="text-[7px] md:text-[8px] text-neon-cyan uppercase tracking-[0.3em] font-bold">Neural IDE</span>
          </div>
        </div>

        <div className="h-8 w-[1px] bg-cyber-border mx-1 md:mx-2 hidden sm:block" />

        <div className="flex items-center gap-2 md:gap-4">
          <div className="relative group hidden sm:block">
            <div className="absolute -inset-0.5 bg-neon-cyan/20 rounded-md blur opacity-0 group-hover:opacity-100 transition duration-500"></div>
            <select
              value={language}
              onChange={(e) => onLanguageChange(e.target.value)}
              className="relative bg-black/40 border border-cyber-border text-[10px] md:text-xs text-gray-300 px-2 md:px-3 py-1 md:py-1.5 rounded-md focus:outline-none focus:border-neon-cyan/50 cursor-pointer font-mono appearance-none pr-6 md:pr-8"
            >
              {Object.keys(SUPPORTED_LANGUAGES).map(lang => (
                <option key={lang} value={lang}>{lang.charAt(0).toUpperCase() + lang.slice(1)}</option>
              ))}
            </select>
            <Globe size={10} className="absolute right-2 md:right-2.5 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" />
          </div>

          <button
            onClick={onRun}
            disabled={isRunning}
            className={`
              relative group flex items-center gap-1 md:gap-2 px-3 md:px-5 py-1 md:py-1.5 rounded-md font-bold text-[10px] md:text-xs uppercase tracking-widest transition-all
              ${isRunning 
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
                : 'bg-neon-green text-black hover:shadow-[0_0_20px_rgba(0,255,159,0.6)] active:scale-95'}
            `}
          >
            <Play size={12} fill="currentColor" />
            <span className="hidden xs:inline">{isRunning ? 'Running...' : 'Run'}</span>
            <span className="xs:hidden">{isRunning ? '...' : 'Run'}</span>
          </button>
        </div>
      </div>

      <div className="flex items-center gap-1 md:gap-3">
        <button 
          onClick={onToggleAI}
          className={`p-2 rounded-md transition-all flex items-center gap-2 ${isAIOpen ? 'bg-neon-pink/20 text-neon-pink' : 'text-gray-400 hover:text-neon-pink hover:bg-neon-pink/10'}`}
          title="Toggle AI Assistant"
        >
          {isAIOpen ? <X size={18} /> : <MessageSquare size={18} />}
          <span className="text-[10px] font-bold uppercase tracking-tighter hidden md:inline">AI Assistant</span>
        </button>

        <div className="hidden sm:flex items-center gap-1 md:gap-3">
          <button 
            onClick={onSave}
            className="p-2 text-gray-400 hover:text-neon-cyan hover:bg-neon-cyan/10 rounded-md transition-all"
            title="Save Project"
          >
            <Save size={18} />
          </button>
          <button 
            onClick={onDownload}
            className="p-2 text-gray-400 hover:text-neon-cyan hover:bg-neon-cyan/10 rounded-md transition-all"
            title="Download File"
          >
            <Download size={18} />
          </button>
        </div>

        <div className="h-6 w-[1px] bg-cyber-border mx-1 hidden md:block" />
        
        <div className="hidden lg:flex items-center gap-3 pl-4 border-l border-cyber-border">
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-gray-500 font-mono">SYSTEM_STATUS</span>
            <span className="text-[10px] text-neon-green font-mono">ONLINE</span>
          </div>
          <div className="w-2 h-2 rounded-full bg-neon-green shadow-[0_0_8px_rgba(0,255,159,0.8)] animate-pulse" />
        </div>
      </div>
    </nav>
  );
}
