import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Send, Bot, User, Sparkles, Loader2, Code2, X } from 'lucide-react';
import { ChatMessage, FileNode } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface AIChatProps {
  activeFile: FileNode | null;
  onApplyCode: (code: string) => void;
  onClose?: () => void;
}

export default function AIChat({ activeFile, onApplyCode, onClose }: AIChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Greetings, User. I am CompilerX AI. How can I assist your coding session today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: userMsg,
        config: {
          systemInstruction: `You are a professional AI coding assistant integrated into "CompilerX", a cyberpunk-themed IDE. 
          Your tone is helpful, technical, and slightly futuristic. 
          When providing code, use markdown code blocks. 
          If the user asks to "fix errors" or "improve code", analyze the current code and provide the full corrected version in a code block.
          Context: The user is currently editing a ${activeFile?.language || 'unknown'} file named "${activeFile?.name || 'untitled'}".
          Current code content:
          \`\`\`${activeFile?.language || ''}
          ${activeFile?.content || ''}
          \`\`\``
        }
      });
      const responseText = result.text || "I apologize, but I encountered a glitch in my reasoning matrix.";
      
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "ERROR: Connection to Neural Network lost. Please check your API key." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const extractCode = (text: string) => {
    const match = text.match(/```[\w]*\n([\s\S]*?)```/);
    return match ? match[1] : null;
  };

  return (
    <div className="w-full md:w-80 bg-cyber-panel border-l border-cyber-border flex flex-col h-full overflow-hidden shadow-[-10px_0_30px_rgba(0,0,0,0.5)]">
      <div className="p-4 border-b border-cyber-border bg-black/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-neon-purple" />
          <div className="text-xs font-bold uppercase tracking-widest text-neon-purple">AI Assistant</div>
        </div>
        {onClose && (
          <button 
            onClick={onClose}
            className="p-1 hover:bg-white/10 rounded text-gray-500 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
        {messages.map((msg, i) => (
          <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`flex items-center gap-2 mb-1 text-[10px] uppercase tracking-tighter ${msg.role === 'user' ? 'text-neon-cyan' : 'text-neon-purple'}`}>
              {msg.role === 'user' ? <User size={10} /> : <Bot size={10} />}
              {msg.role === 'user' ? 'User' : 'CompilerX AI'}
            </div>
            <div className={`
              max-w-[95%] p-3 rounded-lg text-sm leading-relaxed
              ${msg.role === 'user' ? 'bg-neon-cyan/10 border border-neon-cyan/20 text-gray-200' : 'bg-neon-purple/10 border border-neon-purple/20 text-gray-300'}
            `}>
              <div className="whitespace-pre-wrap break-words font-sans">
                {msg.text}
              </div>
              
              {msg.role === 'model' && extractCode(msg.text) && (
                <button
                  onClick={() => onApplyCode(extractCode(msg.text)!)}
                  className="mt-3 w-full py-1.5 px-2 bg-neon-purple/20 hover:bg-neon-purple/40 border border-neon-purple/40 rounded text-[10px] font-bold uppercase tracking-widest text-neon-purple transition-all flex items-center justify-center gap-2"
                >
                  <Code2 size={12} />
                  Apply to Editor
                </button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-center gap-2 text-neon-purple animate-pulse">
            <Loader2 size={14} className="animate-spin" />
            <span className="text-[10px] uppercase tracking-widest">Processing...</span>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-cyber-border bg-black/20">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask AI for help..."
            className="w-full bg-black/40 border border-cyber-border rounded-lg p-3 pr-10 text-sm focus:outline-none focus:border-neon-purple/50 transition-all resize-none h-20 placeholder:text-gray-600"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute bottom-3 right-3 p-1.5 text-neon-purple hover:text-white disabled:text-gray-700 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
