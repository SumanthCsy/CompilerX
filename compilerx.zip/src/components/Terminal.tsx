import React from 'react';
import { Terminal as TerminalIcon, Trash2, ChevronRight, AlertCircle, CheckCircle2, Keyboard } from 'lucide-react';
import { ExecutionResult } from '../types';

interface TerminalProps {
  result: ExecutionResult | null;
  isLoading: boolean;
  onClear: () => void;
  stdin: string;
  onStdinChange: (val: string) => void;
}

export default function Terminal({ result, isLoading, onClear, stdin, onStdinChange }: TerminalProps) {
  return (
    <div className="h-64 md:h-48 bg-cyber-panel border-t border-cyber-border flex flex-col overflow-hidden">
      <div className="px-4 py-2 border-b border-cyber-border flex justify-between items-center bg-black/40">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400">
            <TerminalIcon size={14} className="text-neon-green" />
            Terminal
          </div>
          
          <div className="hidden sm:flex items-center gap-2 bg-black/40 border border-cyber-border rounded px-2 py-0.5">
            <Keyboard size={10} className="text-neon-cyan" />
            <input 
              type="text"
              value={stdin}
              onChange={(e) => onStdinChange(e.target.value)}
              placeholder="Standard Input (stdin)..."
              className="bg-transparent border-none outline-none text-[10px] text-neon-cyan placeholder:text-neon-cyan/30 w-32 md:w-48 font-mono"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          {isLoading && (
            <div className="flex items-center gap-2 text-[10px] text-neon-cyan animate-pulse">
              <div className="w-2 h-2 rounded-full bg-neon-cyan shadow-[0_0_8px_rgba(0,243,255,0.8)]" />
              EXECUTING...
            </div>
          )}
          <button 
            onClick={onClear}
            className="p-1 hover:bg-white/10 rounded text-gray-500 hover:text-neon-pink transition-colors"
            title="Clear Console"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* Mobile Stdin */}
      <div className="sm:hidden px-4 py-1 border-b border-cyber-border bg-black/20 flex items-center gap-2">
        <Keyboard size={10} className="text-neon-cyan" />
        <input 
          type="text"
          value={stdin}
          onChange={(e) => onStdinChange(e.target.value)}
          placeholder="Stdin..."
          className="bg-transparent border-none outline-none text-[10px] text-neon-cyan placeholder:text-neon-cyan/30 flex-1 font-mono"
        />
      </div>
      
      <div className="flex-1 p-4 font-mono text-sm overflow-y-auto bg-black/20 selection:bg-neon-green/20">
        {!result && !isLoading && (
          <div className="text-gray-600 flex items-center gap-2">
            <ChevronRight size={14} />
            Ready for execution. Press Run to start.
          </div>
        )}
        
        {isLoading && (
          <div className="text-neon-cyan/50 italic">
            Connecting to secure sandbox...
          </div>
        )}

        {result && result.run && (
          <div className="space-y-2">
            {result.compile && result.compile.output && (
              <div className="mb-2">
                <div className="text-[10px] text-gray-500 uppercase mb-1 flex items-center gap-1">
                  <AlertCircle size={10} /> Compilation
                </div>
                <pre className={`whitespace-pre-wrap ${result.compile.code !== 0 ? 'text-red-500' : 'text-gray-400'}`}>
                  {result.compile.output}
                </pre>
              </div>
            )}
            
            <div>
              <div className="text-[10px] text-gray-500 uppercase mb-1 flex items-center gap-1">
                <CheckCircle2 size={10} className="text-neon-green" /> Output
              </div>
              <pre className={`whitespace-pre-wrap ${result.run.code !== 0 ? 'text-red-500' : 'text-neon-green'}`}>
                {result.run.output || (result.run.code === 0 ? '(No output)' : '')}
              </pre>
            </div>
            
            {result.run.code !== 0 && (
              <div className="text-red-500 text-xs mt-2 border-t border-red-500/20 pt-2">
                Process exited with code {result.run.code}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
