import React from 'react';
import { FileNode } from '../types';
import { File, FileCode, Plus, X, Folder } from 'lucide-react';

interface SidebarProps {
  files: FileNode[];
  activeFileId: string;
  onFileSelect: (id: string) => void;
  onFileClose: (id: string) => void;
  onFileCreate: () => void;
}

export default function Sidebar({ files, activeFileId, onFileSelect, onFileClose, onFileCreate }: SidebarProps) {
  return (
    <div className="w-64 bg-cyber-panel border-r border-cyber-border flex flex-col h-full overflow-hidden">
      <div className="p-4 border-bottom border-cyber-border flex justify-between items-center bg-black/20">
        <div className="flex items-center gap-2 text-neon-cyan font-bold text-xs uppercase tracking-widest">
          <Folder size={14} />
          Explorer
        </div>
        <button 
          onClick={onFileCreate}
          className="p-1 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-neon-green"
          title="New File"
        >
          <Plus size={16} />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto py-2">
        {files.map(file => (
          <div
            key={file.id}
            onClick={() => onFileSelect(file.id)}
            className={`
              group flex items-center justify-between px-4 py-1.5 cursor-pointer transition-all
              ${activeFileId === file.id ? 'bg-neon-cyan/10 border-l-2 border-neon-cyan text-white' : 'hover:bg-white/5 text-gray-400'}
            `}
          >
            <div className="flex items-center gap-2 overflow-hidden">
              <FileCode size={14} className={activeFileId === file.id ? 'text-neon-cyan' : 'text-gray-500'} />
              <span className="text-sm truncate font-mono">{file.name}</span>
            </div>
            
            <button
              onClick={(e) => {
                e.stopPropagation();
                onFileClose(file.id);
              }}
              className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-white/10 rounded text-gray-500 hover:text-neon-pink transition-all"
            >
              <X size={12} />
            </button>
          </div>
        ))}
        
        {files.length === 0 && (
          <div className="p-4 text-center text-gray-600 text-xs italic">
            No files open
          </div>
        )}
      </div>

      <div className="p-4 border-t border-cyber-border bg-black/20">
        <div className="text-[10px] text-gray-500 uppercase tracking-tighter mb-2">Project Info</div>
        <div className="text-[11px] text-gray-400 font-mono">
          <div className="flex justify-between">
            <span>Files:</span>
            <span className="text-neon-green">{files.length}</span>
          </div>
          <div className="flex justify-between">
            <span>Status:</span>
            <span className="text-neon-cyan">Ready</span>
          </div>
        </div>
      </div>
    </div>
  );
}
